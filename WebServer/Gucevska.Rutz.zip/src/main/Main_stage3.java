package main;

import tcp.TCPAcceptor_stage3;

public class Main_stage3 {
	public static void main(String[] args) {
		//Just launching the TCPAcceptor of the stage 3.
		TCPAcceptor_stage3.getInstance().start();
	}
}